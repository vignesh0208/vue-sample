var api = { template: `
    <section class="api-login">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="heading">
                        <h4>Prev Log</h4>
                    </div>
                    <div class="card-inner">
                        <h5>Sample</h5>
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                <th scope="col">API</th>
                                <th scope="col">Monday</th>
                                <th scope="col">Tuesday</th>
                                <th scope="col">Wednesday</th>
                                <th scope="col">Thursday</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <th scope="row">1</th>
                                <td>Mark</td>
                                <td>Otto</td>
                                <td>@mdo</td>
                                <td>hello</td>
                                </tr>
                                <tr>
                                <th scope="row">2</th>
                                <td>Jacob</td>
                                <td>Thornton</td>
                                <td>@fat</td>
                                <td>hello</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="heading">
                        <h4>Current Log <span style="float:right">
                                <button type="button" class="btn btn-primary">Restart All</button>
                        </span></h4>
                    </div>
                    <div class="card-inner">
                        <h5>Sample <span style="float:right">
                                <button type="button" class="btn btn-secondary">Restart</button>
                        </span></h5>
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                <th scope="col">API</th>
                                <th scope="col">Monday</th>
                                <th scope="col">Tuesday</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <th scope="row">1</th>
                                <td>Mark</td>
                                <td>Otto</td>
                                </tr>
                                <tr>
                                <th scope="row">2</th>
                                <td>Jacob</td>
                                <td>Thornton</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>` }
var edit = {
    data() {
        return {
            tasks: [],
            x: '',
            tasksvalue: '',
            selected: ''
        }
    },
    methods: {
        onAdd: function(x){
            if(x == "") {
                alert("Enter input")
            }
            else{
                this.tasks.push(x)
                this.tasks.indexOf(x, 1)
                console.log(x)
                this.tasksvalue = ""
            }
        }
    },
    template: `
    <section class="api-login-sample">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="offset-md-1 col-md-10">
                            <div class="card-inner-sample">
                                <form class="text-center login-top p-3">
                                    <p class="h4 mb-4">Select</p>
                                    <div>
                                        <input type="text" v-model="tasksvalue" class="form-control mb-4" placeholder="name" />
                                        <select class="form-control" v-model="selected">
                                            <option value="Select One">Select One</option>
                                            <option value="One">1</option>
                                            <option value="Two">2</option>
                                            <option value="Three">3</option>
                                            <option value="Four">4</option>
                                        </select>
                                        <input class="btn btn-info btn-block my-4" type="submit" @click="onAdd(tasksvalue)" value="Update"/>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="heading">
                        <h4>Current Log</h4>
                    </div>
                    <div class="card-inner">
                        <h5>Sample</h5>
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                <th scope="col">API</th>
                                <th scope="col">Name</th>
                                <th scope="col">Selection type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(task, index) in tasks">
                                <th scope="row">{{index}}</th>
                                <td>{{task}}</td>
                                <td>{{selected}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
` }

const routes = [
  { path: '/api', component: api, meta: { title: 'API Page' }},
  { path: '/edit', component: edit, meta: { title: 'API Edit Page'}}
]
const router = new VueRouter({
  routes
})
const app = new Vue({
  router
}).$mount('#app')