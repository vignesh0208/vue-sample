<html>
    <head>
     
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    </head>
    <body>
            <div class="container">
                    <div class="row">
                       <div class="col-sm-4"></div>
                       <div class="col-sm-4">
                          <div class="row chatheader" style="background:#006253;">
                             <div class="col-sm-6" >
                                <p><i class="fa fa-arrow-left"style="padding: 8px;font-size: 16px;color: #ffffff;"></i><span style="font-size: 16px;color: #ffffff;">openchat</span>
                                </p>
                             </div>
                             <div class="col-sm-6">
                                <i class="fa fa-ellipsis-v" style="padding: 8px;font-size: 16px;float: right;color: #ffffff;"></i>
                                <i class="fas fa-phone" style="padding: 8px;font-size: 16px;float: right;color: #ffffff;"></i>
                                <i class="fa fa-video-camera" style="padding: 8px;font-size: 16px;float: right;color: #ffffff;"></i>
                             </div>
                          </div>
                          <div class="row">
                             <div class="col-sm-12" style="background-color:blue;color:#ffffff;">
                                <br>
                                <br><br><br>
                                <p>hi how are you</p>
                                <br><br><br><br><br>
                                <p>hi how are you</p>
                                <br><br><br><br>
                                <p>hi how are you</p>
                                <br><br><br><br><br><br>
                                <br>
                                <br><br><br><br><br><br>
                                <br><br><br><br><br>
                                <p>hi how are you</p>
                                <br><br><br><br><br><br>
                                <p>hi how are you</p>
                                <br><br><br><br><br>
                                <div class="row mar">
                                   <div class="col-sm-2" style="background-color: #ffffff;border-bottom-left-radius: 40px;
                                      border-top-left-radius: 40px;padding-right: 0px;"><i class="fa fa-smile-o" style="
                                      padding: 18px;font-size: 20px;color: #000000;float: right;"></i></div>
                                   <div class="col-sm-4" style="background-color: #ffffff;padding: 9px;"></i><input type="text" class="form-control"   placeholder="Text Message"/></div>
                                   <div class="col-sm-2" style="background-color: #ffffff;"><i class="fa fa-camera" style="
                                      padding: 18px;font-size: 20px;color: #000000;float: right;"></i></div>
                                   <div class="col-sm-2" style="background-color: #ffffff;border-bottom-right-radius: 40px;
                                      border-top-right-radius: 40px;"><i class="fa fa-paperclip"style="
                                      padding: 18px;font-size: 20px;color: #000000;float: right;"></i></div>
                                   <div class="col-sm-2"><i class="fa fa-microphone" style="
                                      padding: 18px;font-size: 18px;color: #ffffff;"></i></div>
                                </div>
                             </div>
                          </div>
                          <div class="col-sm-4"></div>
                       </div>
                    </div>
                 </div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <style>
        .row.mar {
    margin-right: 0px;
    margin-left: 0px;
}

i.fa.fa-microphone {
    background: green;
    padding: 18px;
    border-radius: 50%;
}
input.form-control {
    padding: 18px;
    float: right;
    
}
.row.mar {
    position: sticky;
    bottom: 0px;
    z-index: 1;
}

.row.chatheader {
    position: sticky;
    top: 0px;
    z-index: 1;
}
</style>
  
  </body>
</html>
